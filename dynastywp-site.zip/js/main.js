/* Dynasty Wealth Partners — shared behavior */

// Mobile nav
const toggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.main-nav');
if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
  });
}

// Scroll reveals
const observer = new IntersectionObserver((entries) => {
  entries.forEach((e) => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      observer.unobserve(e.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));

// Testimonial read-more
document.querySelectorAll('.testimonial-toggle').forEach((btn) => {
  btn.addEventListener('click', () => {
    const more = btn.parentElement.querySelector('.testimonial-more');
    const open = more.classList.toggle('open');
    btn.textContent = open ? 'Read less' : 'Read the full story';
    btn.setAttribute('aria-expanded', open);
  });
});

// Team bio modals
document.querySelectorAll('[data-modal-target]').forEach((card) => {
  card.addEventListener('click', () => {
    const modal = document.getElementById(card.dataset.modalTarget);
    if (!modal) return;
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
    modal.querySelector('.modal-close').focus();
  });
});
document.querySelectorAll('.modal-overlay').forEach((overlay) => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay || e.target.closest('.modal-close')) {
      overlay.classList.remove('open');
      document.body.style.overflow = '';
    }
  });
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach((m) => m.classList.remove('open'));
    document.body.style.overflow = '';
  }
});

// Forms (front-end only — wire up HighLevel / a form service before launch)
document.querySelectorAll('.contact-form form, .form-embed form').forEach((form) => {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const note = form.querySelector('.form-status');
    if (note) {
      note.textContent = 'Thank you! A member of our team will respond to you shortly.';
      note.style.display = 'block';
    }
    form.reset();
  });
});

// FAQ accordion — one open at a time
document.querySelectorAll('.faq-list').forEach((list) => {
  list.querySelectorAll('details').forEach((d) => {
    d.addEventListener('toggle', () => {
      if (d.open) list.querySelectorAll('details[open]').forEach((o) => { if (o !== d) o.open = false; });
    });
  });
});

// DWP Process — 3D scroll effects (GSAP ScrollTrigger, loaded on the homepage only)
const steps = document.querySelectorAll('.process-step');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (steps.length && window.gsap && window.ScrollTrigger && !reduceMotion) {
  gsap.registerPlugin(ScrollTrigger);
  steps.forEach((step) => {
    step.classList.remove('reveal');
    gsap.fromTo(step,
      { opacity: 0, y: 90, rotateX: 28, scale: 0.92, transformOrigin: 'center top' },
      {
        opacity: 1, y: 0, rotateX: 0, scale: 1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: step,
          start: 'top 88%',
          end: 'top 55%',
          scrub: 0.6,
        },
      }
    );
    ScrollTrigger.create({
      trigger: step,
      start: 'top 60%',
      end: 'bottom 35%',
      onToggle: (self) => step.classList.toggle('is-active', self.isActive),
    });
  });
}
