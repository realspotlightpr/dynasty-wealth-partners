# Dynasty Wealth Partners — Redesigned Website

Static 5-page site (no build step). Open `index.html` in a browser, push the folder to GitHub, or deploy to any static host.

## Pages

- `index.html` — Home (hero video, DWP Process, services, awards, testimonial, founder, CTA)
- `what-we-do.html` — Services detail (5 alternating sections)
- `team.html` — Team grid, each card opens an accessible bio modal (bios preserved verbatim)
- `licenses.html` — Licensing / regulatory compliance
- `contact.html` — Contact form + office info

## IMPORTANT: add the images

Every image references `images/dwp_<name>` with an automatic fallback to the current live CDN, so the site works immediately. For a fully self-hosted site:

1. Find the 33 files starting with `dwp_` in your **Downloads** folder (downloaded during the content-archive step).
2. Move them into this folder's `images/` directory. Keep the filenames exactly as-is.

Consider compressing the large PNGs (several are 1–2.4 MB) with tinypng.com or `squoosh.app` before launch — big LCP win.

## Before launch checklist

- [ ] **Contact form is front-end only.** Wire it to a form service (Formspree, Basin, GHL form webhook) or a backend. Look for the `NOTE:` comment in `contact.html`.
- [ ] Hero video still streams from the old GoHighLevel storage URL. Download it and self-host if you're leaving GHL: `https://storage.googleapis.com/msgsndr/siqsEVBkNgcToKRz4UB5/media/68dc3a96894d00d5496fdf9c.mp4`
- [ ] Same for the Customer Relationship Summary PDF (footer link) — currently points at GHL storage.
- [ ] Confirm which Forbes claim is compliance-approved for Gary (homepage says "Forbes and MDRT top 100"; team bio says "Forbes 2024 Top Best in State Financial Security Professional" — both kept as on the original site).
- [ ] The old site's contact-page testimonials were lorem ipsum placeholders with real client names — replaced here with a neutral "Who We Serve" strip. Add real quotes (with compliance disclosures) when available.
- [ ] The "14 Day Free Trial" popup from the old site was leftover funnel-template content — intentionally removed.
- [ ] Add a privacy policy page (consent text references one).

## Content source

All copy comes from `../dynastywp-content-archive.md`, extracted verbatim from dynastywp.com on 2026-08-05. Team bios, services, process, testimonial, and compliance text are unchanged.
